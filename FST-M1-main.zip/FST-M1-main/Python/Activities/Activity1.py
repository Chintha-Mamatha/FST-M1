name = input( "What is your name: " )
age = int( input( "How old are you: " ) )
year = str( ( 2025 - age ) + 100 )
print( name + " will be 100 years old in the year " + year )